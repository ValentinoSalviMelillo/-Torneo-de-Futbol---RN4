Como poryecto me toco hacer un app de futbol, en mi caso lo hice, de la Copa Libertadore. 
Me tomo bastante tiempo pero lo lo hice. En el archivo "APP"; estan todos los archivos que use para crear la app, la cual cuenta tambien con una base de datos. 
